package com.tixar.rtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
